from django.shortcuts import render, get_object_or_404
from .models import Post

def all_posts(request):
    posts = Post.objects.all().order_by('-date_posted')
    return render(request, 'blog/all_posts.html', {'posts': posts})

def single_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    return render(request, 'blog/single_post.html', {'post': post})
